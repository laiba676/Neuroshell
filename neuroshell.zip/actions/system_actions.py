import os
import subprocess
import webbrowser
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
from ctypes import cast, POINTER
from comtypes import CLSCTX_ALL
import pyautogui
import ctypes
import subprocess
import time
import pythoncom

def _get_volume_interface():
    pythoncom.CoInitialize()
    devices = AudioUtilities.GetSpeakers()
    interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
    return cast(interface, POINTER(IAudioEndpointVolume))

def lower_volume():
    volume = _get_volume_interface()
    current = volume.GetMasterVolumeLevelScalar()
    volume.SetMasterVolumeLevelScalar(max(0.0, current - 0.1), None)

def increase_volume():
    volume = _get_volume_interface()
    current = volume.GetMasterVolumeLevelScalar()
    volume.SetMasterVolumeLevelScalar(min(1.0, current + 0.1), None)

def unmute_volume():
    volume = _get_volume_interface()
    volume.SetMute(1, None)

def mute_volume():
    volume = _get_volume_interface()
    volume.SetMute(0, None)

def open_chrome():
    try:
        os.startfile("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe")
    except FileNotFoundError:
        print("Chrome not found.")

def open_whatsapp():
    webbrowser.open("https://web.whatsapp.com/")

def open_app(path):
    try:
        os.startfile(path)
    except Exception as e:
        print("Failed to open app:", e)

def increase_brightness():
    try:
        # Windows only: increase brightness using powershell
        subprocess.call('powershell (Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1, 100)', shell=True)
        print("Brightness increased.")
    except Exception as e:
        print("Failed to increase brightness:", e)

def decrease_brightness():
    try:
        subprocess.call('powershell (Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods).WmiSetBrightness(1, 20)', shell=True)
        print("Brightness decreased.")
    except Exception as e:
        print("Failed to decrease brightness:", e)

def shutdown_system():
    os.system("shutdown /s /t 1")

def restart_system():
    os.system("shutdown /r /t 1")

def lock_screen():
    ctypes.windll.user32.LockWorkStation()

def sleep_system():
    os.system("rundll32.exe powrprof.dll,SetSuspendState 0,1,0")

def take_screenshot():
    screenshot = pyautogui.screenshot()
    screenshot.save("ss/screenshot.png")
    print("Screenshot saved as screenshot.png")

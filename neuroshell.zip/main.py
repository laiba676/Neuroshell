import streamlit as st
import threading
import time
from speech.recognizer import listen
from speech.tts import speak
from nlp.intent_matcher import match_intent
from nlp.chat_responses import get_chat_reply
from nlp.google_cse import google_cse

wake_word = "hey bugsbee"

# Streamlit app state init
st.set_page_config(page_title="BugsBee", layout="centered")
st.title("🎙️ BugsBee - My Voice Assistant")

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

if "wake_thread_started" not in st.session_state:
    st.session_state.wake_thread_started = True
    st.session_state.listening_flag = False

    def wake_word_listener():
        while True:
            text = listen()
            if text and wake_word in text.lower():
                st.session_state.listening_flag = True
                speak("Yes?")
                st.experimental_rerun()
            time.sleep(1)

    threading.Thread(target=wake_word_listener, daemon=True).start()

# Show chat history
for role, message in st.session_state.chat_history:
    with st.chat_message(role):
        st.markdown(message)

# Manual or auto (wake word) listener
if st.button("🎧 Start Listening") or st.session_state.listening_flag:
    with st.spinner("Listening..."):
        user_input = listen()
    st.session_state.listening_flag = False

    if user_input:
        st.session_state.chat_history.append(("user", user_input))
        st.chat_message("user").markdown(user_input)

        response = get_chat_reply(user_input.lower())

        if not response:
            action = match_intent(user_input.lower())
            if action:
                action()
                response = "Command executed."

        if not response and "exit" in user_input.lower():
            response = "Goodbye!"

        if not response:
            response = google_cse(user_input.lower())

        st.session_state.chat_history.append(("assistant", response))
        st.chat_message("assistant").markdown(response)

        speak(response)

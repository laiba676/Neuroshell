def get_chat_reply(user_input):
    responses = {
        "hello": "Hi there!",
        "how are you": "I'm functioning well, thanks!",
        "what is your name": "I'm your voice assistant.",
        "thank you": "You're welcome!",
        "tell me a joke": "Why did the computer sneeze? It had a virus!"
    }
    for phrase in responses:
        if phrase in user_input:
            return responses[phrase]
    return None

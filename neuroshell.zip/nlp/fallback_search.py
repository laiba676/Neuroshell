import webbrowser
import random

def fallback_response(user_input):
    # Simulate smart response
    keywords = extract_keywords(user_input)
    
    if not keywords:
        return "I'm not sure how to respond to that."

    query = " ".join(keywords)
    # Open Google search in browser (optional)
    webbrowser.open(f"https://www.google.com/search?q={query}")

    # Or just respond with message
    fallback_messages = [
        f"I'm not sure, but I searched this for you: '{query}'",
        f"Let me help you find more about: '{query}'",
        f"I'm not trained for that, but here’s what I found on: '{query}'"
    ]
    return random.choice(fallback_messages)

def extract_keywords(text):
    # Simple keyword extraction (you can replace with spaCy/RAKE/KeyBERT later)
    stopwords = {"what", "is", "the", "how", "are", "who", "tell", "me", "a", "about", "to", "of", "on"}
    words = text.lower().split()
    keywords = [word for word in words if word not in stopwords]
    return keywords[:5]  # Limit to top 5

import requests

API_KEY = "AIzaSyDxtHo-GWbW_UPeoGiksbYfc9gTT5otSGw"
CSE_ID = "3472390ca41d04621"

def google_cse(query):
    url = f"https://www.googleapis.com/customsearch/v1?q={query}&key={API_KEY}&cx={CSE_ID}"
    try:
        res = requests.get(url).json()
        if "items" in res:
            return res["items"][0]["snippet"]
        else:
            return "Sorry, I couldn't find anything relevant."
    except Exception as e:
        return "There was an error fetching information."

from rapidfuzz import fuzz
from actions.system_actions import (
    lower_volume, increase_volume, mute_volume, unmute_volume,
    open_chrome, open_whatsapp,
    increase_brightness, decrease_brightness,
    shutdown_system, restart_system, lock_screen,
    take_screenshot, sleep_system
)

INTENT_MAP = {
    # Volume
    "lower the volume": lower_volume,
    "decrease the volume": lower_volume,
    "volume down": lower_volume,

    "increase the volume": increase_volume,
    "volume up": increase_volume,

    "mute": mute_volume,
    "mute volume": mute_volume,

    "unmute": unmute_volume,
    "unmute volume": unmute_volume,

    # Brightness
    "increase brightness": increase_brightness,
    "brightness up": increase_brightness,

    "decrease brightness": decrease_brightness,
    "brightness down": decrease_brightness,

    # Apps
    "open chrome": open_chrome,
    "launch chrome": open_chrome,
    "open whatsapp": open_whatsapp,
    "launch whatsapp": open_whatsapp,

    # System
    "shutdown": shutdown_system,
    "turn off computer": shutdown_system,

    "restart": restart_system,
    "reboot": restart_system,

    "lock screen": lock_screen,
    "lock my pc": lock_screen,

    "sleep": sleep_system,
    "put to sleep": sleep_system,

    # Screenshot
    "take screenshot": take_screenshot,
    "capture screen": take_screenshot
}

def match_intent(user_input):
    for phrase, action in INTENT_MAP.items():
        score = fuzz.partial_ratio(user_input, phrase)
        if score > 80:
            return action
    return None

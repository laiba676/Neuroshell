from gtts import gTTS
import pygame
import time
import os
import uuid

def speak(text):
    try:
        # Generate a unique filename for the MP3
        filename = f"temp_{uuid.uuid4()}.mp3"

        # Generate speech
        tts = gTTS(text=text, lang='en')
        tts.save(filename)

        # Initialize and play using pygame
        pygame.mixer.init()
        pygame.mixer.music.load(filename)
        pygame.mixer.music.play()

        # Wait until playback finishes
        while pygame.mixer.music.get_busy():
            time.sleep(0.3)

        # Cleanup
        pygame.mixer.music.unload()
        os.remove(filename)

    except Exception as e:
        print("Error in speak():", e)
